package my_package;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;

public class welcome extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane2;
	private JTextField txtWelcome;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					welcome frame = new welcome();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public welcome() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane2 = new JPanel();
		contentPane2.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane2);
		contentPane2.setLayout(null);
		
		txtWelcome = new JTextField();
		txtWelcome.setFont(new Font("Times New Roman", Font.BOLD, 20));
		txtWelcome.setBounds(10, 97, 126, 20);
		txtWelcome.setText("WELCOME!");
		contentPane2.add(txtWelcome);
		txtWelcome.setColumns(10);
	}

}
