package my_package;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import com.mysql.jdbc.PreparedStatement;
import javax.swing.JOptionPane;


public class newconnection {
	
	
	public static void validarUsuario(String usuario) {
        // Mostrar un mensaje de alerta con el nombre del usuario
        JOptionPane.showMessageDialog(null, "Hola " + usuario, "Mensaje de Alerta", JOptionPane.INFORMATION_MESSAGE);
        // Llamar a la función para conectarse a la base de datos MySQL
        conectarMySQL(usuario);
    }
    
    public static void conectarMySQL(String usuario) {
        // Definir la cadena de conexión
        String url = "jdbc:mysql://localhost:3306/musica_practica?allowPublicKeyRetrieval=true&useSSL=false";
        String username = "root";
        String password = "admin";
        boolean salir = true;
        String[] mismusicos;
        //String usuario = my_frame.textArea.getText()
        Connection connection = null;
        
        try {
            // Establecer la conexión
            connection = DriverManager.getConnection(url, username, password);
            JOptionPane.showMessageDialog(null, "Conexión exitosa a la base de datos", "Mensaje de Alerta", JOptionPane.INFORMATION_MESSAGE);
            //////INICIO
            String myquery = "SELECT musicos.nombre FROM musica_practica.musicos WHERE musicos.nombre LIKE '%"+ usuario+ "%'";
            PreparedStatement statement = (PreparedStatement) connection.prepareStatement(myquery);
            ResultSet resultSet = statement.executeQuery(); 
            //segunda query
            String mysecondquery = "SELECT nombre, fecha_nacimiento, instrumento FROM musica_practica.musicos WHERE musicos.nombre LIKE '%" +usuario+ "%'";
            PreparedStatement statementnuevo = (PreparedStatement) connection.prepareStatement(mysecondquery);
            ResultSet resultSetNuevo = statementnuevo.executeQuery(); 
            
            
            
            {
            	// SI NO ENCUENTRA NINGÚN USUARIO EN BASE DE DATOS CON ESE NOMBRE, POP UP INFORMANDO DE LOS MISMO
            	if (!resultSet.next()) {
            		JOptionPane.showMessageDialog(null, "User NOT found", "Mensaje de Alerta", JOptionPane.INFORMATION_MESSAGE);
            	}
            	else {
            		String musicos = resultSet.getString("musicos.nombre");
            		if (usuario.equals(musicos)) {
            			if (resultSetNuevo.next()) {
            				String name = resultSetNuevo.getString("nombre");
            				String fecha = resultSetNuevo.getString("fecha_nacimiento");
            				String instrumento = resultSetNuevo.getString("instrumento");
            				String strtoprint = "WELCOME!" + "\n" + "Nombre: " + name +  "\n" + "Fecha de nacimiento: " + fecha + "\n" + "Instrumento: " +instrumento;
            		System.out.println(name + " " + instrumento + " " + fecha);	
            		JOptionPane.showMessageDialog(null, strtoprint, "Mensaje de Alerta", JOptionPane.INFORMATION_MESSAGE);}}
            		
            		 //IF ELSE PARA ARROJAR ERROR EN CASO DE DARLE OK DEJANDO LA CAJA VACÍA
            		else { JOptionPane.showMessageDialog(null, "User NOT found", "Mensaje de Alerta", JOptionPane.INFORMATION_MESSAGE);}
            	}
                
            		//////////////////////////INICIO
            		/*
            		while (resultSet.next()) {
                	//System.out.println(((Object)resultSet.getClass().getSimpleName());
                	String musicos = resultSet.getString("musicos.nombre");
                	//System.out.println(musicos);
                    if (usuario.equals(musicos))
                    	
                    {	
                    	
                    	JOptionPane.showMessageDialog(null, "User found", "Mensaje de Alerta", JOptionPane.INFORMATION_MESSAGE);
                    	
                    	//continue;
                    	//salir = false;
                    	
                    }
                    else {
                    	JOptionPane.showMessageDialog(null, "User NOT found", "Mensaje de Alerta", JOptionPane.INFORMATION_MESSAGE);
                    	break;
                    	//break;
                    }
                }
                       */            
            ///// FIN
        }} catch (SQLException e) {
            // Manejar cualquier error
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al conectar a la base de datos", "Mensaje de Alerta", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Cerrar la conexión si está abierta
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                
            }
        }
    }
    }


