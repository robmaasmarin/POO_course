package my_package;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.SystemColor;

public class my_frame extends JFrame {

	private static final long serialVersionUID = 1L;
	public static JTextField textArea;
	private JPanel contentPane;
	public static JTextField txtHola;
	public static JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					my_frame frame = new my_frame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public my_frame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter your musician name:");
		lblNewLabel.setBounds(30, 27, 149, 14);
		contentPane.add(lblNewLabel);
		
		textArea = new JTextField();
		textArea.setBounds(237, 23, 144, 22);
		contentPane.add(textArea);
		
		
		
		txtHola = new JTextField();
		txtHola.setForeground(SystemColor.textHighlight);
		txtHola.setBounds(237, 65, 125, 20);
		contentPane.add(txtHola);
		txtHola.setColumns(10);
		
		JButton btnNewButton = new JButton("Check user");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				connection.checkUser();
				String musico = my_frame.textArea.getText();
				newconnection.validarUsuario(musico);
			}
		});
		btnNewButton.setBounds(30, 64, 89, 23);
		contentPane.add(btnNewButton);
	}
}
