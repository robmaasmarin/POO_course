package my_package;

public class connection {
	
	static String musico = my_frame.textArea.getText();

	public static void checkUser() {
		
		
			
		if (musico.equals("hey")) {
			
			my_frame.txtHola.setText("user found");
			
			
		
		}
		else {
			my_frame.txtHola.setText("user  NOT found");
		
		}
		
		
	}
	
}
